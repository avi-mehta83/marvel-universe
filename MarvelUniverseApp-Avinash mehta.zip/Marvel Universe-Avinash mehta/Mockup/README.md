# Mockup

Show of the differents mockups and versions


--------------------

### English version ###
HOME layout
![Mockup](HOME-v.english.png)
CHARACTERS layout
![Mockup](CHARACTERS-v.english.png)
CHARACTER layout
![Mockup](CHARACTER-v.english.png)

### Spanish version ###
HOME layout
![Mockup](HOME.png)
CHARACTERS layout
![Mockup](CHARACTERS.png)
CHARACTER layout
![Mockup](CHARACTER.png)
